package cameronmorales.MovieRecommendationSite;

public interface IUserService {
	public int getAge() throws Exception;
}
